# WaveMusic

A native Android music player project.

Features:
- Import audio from Android's file picker.
- Built-in internet browser.
- Download direct audio files through Android DownloadManager.
- Downloaded music is stored in the app's Music directory.
- Local playlist.
- Play / pause / next / previous.
- Media3/ExoPlayer playback.
- Dark modern UI.

Important:
- The browser can browse normal websites.
- A download starts when a website exposes a normal downloadable audio file.
- Protected streaming services and DRM-protected streams cannot be converted into MP3 by this app.
- Only download music you have permission to download.

Open this project in Android Studio and run it on an Android device/emulator.
