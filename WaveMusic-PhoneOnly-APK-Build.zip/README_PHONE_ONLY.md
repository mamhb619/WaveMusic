# WaveMusic — phone-only APK build

1. Create/sign in to a GitHub account in Chrome.
2. Create a new repository named `WaveMusic`.
3. Upload the contents of this project (not the outer ZIP folder).
4. Open **Actions** → **Build WaveMusic APK** → **Run workflow**.
5. Wait for the build to finish.
6. Open the completed workflow run and download the **WaveMusic-debug-apk** artifact.
7. Extract the downloaded artifact if needed, then tap `app-debug.apk` to install it.

Android may ask you to allow your browser/file manager to install unknown apps.

Note: this workflow builds the existing project as a debug APK. It does not bypass DRM or download protected streams from services that do not provide downloadable audio files.
