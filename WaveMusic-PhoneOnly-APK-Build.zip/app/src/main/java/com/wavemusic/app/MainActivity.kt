package com.wavemusic.app

import android.Manifest
import android.app.DownloadManager
import android.content.*
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.view.View
import android.webkit.*
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import java.io.File

data class Track(val title: String, val uri: Uri, val local: Boolean)

class MainActivity : AppCompatActivity() {

    private lateinit var player: ExoPlayer
    private lateinit var titleText: TextView
    private lateinit var artistText: TextView
    private lateinit var progress: SeekBar
    private lateinit var web: WebView
    private lateinit var browserBox: View
    private lateinit var libraryBox: LinearLayout
    private lateinit var playButton: Button
    private val tracks = mutableListOf<Track>()
    private var current = -1

    private val pickAudio = registerForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        uris?.forEach { uri ->
            contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
            tracks.add(Track(getDisplayName(uri), uri, true))
        }
        refreshLibrary()
        if (current == -1 && tracks.isNotEmpty()) load(0)
    }

    private val notificationPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        player = ExoPlayer.Builder(this).build()
        setContentView(makeUi())
        setupBrowser()
        refreshLibrary()

        if (android.os.Build.VERSION.SDK_INT >= 33) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    private fun makeUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 24, 28, 20)
            setBackgroundColor(0xFF09070D.toInt())
        }

        val logo = TextView(this).apply {
            text = "WaveMusic"
            textSize = 26f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 0, 0, 18)
        }
        root.addView(logo)

        val tabs = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        val libraryBtn = Button(this).apply { text = "🎵 Library" }
        val browserBtn = Button(this).apply { text = "🌐 Internet" }
        tabs.addView(libraryBtn, LinearLayout.LayoutParams(0, -2, 1f))
        tabs.addView(browserBtn, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(tabs)

        browserBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }

        web = WebView(this)
        browserBox as LinearLayout
        (browserBox as LinearLayout).addView(
            web, LinearLayout.LayoutParams(-1, 0, 1f)
        )

        val libraryScroll = ScrollView(this)
        libraryBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        libraryScroll.addView(libraryBox)

        root.addView(libraryScroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val now = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 14, 0, 0)
        }

        titleText = TextView(this).apply {
            text = "No song selected"
            textSize = 20f
            setTextColor(0xFFFFFFFF.toInt())
        }
        artistText = TextView(this).apply {
            text = "Add music to begin"
            textSize = 14f
            setTextColor(0xFFAAAAAA.toInt())
        }
        progress = SeekBar(this)

        now.addView(titleText)
        now.addView(artistText)
        now.addView(progress)

        val controls = LinearLayout(this).apply {
            gravity = android.view.Gravity.CENTER
        }

        val previous = Button(this).apply {
            text = "⏮"
            setOnClickListener { previous() }
        }
        playButton = Button(this).apply {
            text = "▶"
            setOnClickListener { togglePlay() }
        }
        val next = Button(this).apply {
            text = "⏭"
            setOnClickListener { next() }
        }

        controls.addView(previous)
        controls.addView(playButton)
        controls.addView(next)
        now.addView(controls)

        val add = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }

        val folder = Button(this).apply {
            text = "📁 Add Music"
            setOnClickListener {
                pickAudio.launch(arrayOf("audio/*"))
            }
        }

        val browser = Button(this).apply {
            text = "🌐 Browse & Download"
            setOnClickListener {
                browserBox.visibility = View.VISIBLE
                libraryScroll.visibility = View.GONE
            }
        }

        add.addView(folder, LinearLayout.LayoutParams(0, -2, 1f))
        add.addView(browser, LinearLayout.LayoutParams(0, -2, 1f))

        now.addView(add)

        root.addView(now)

        libraryBtn.setOnClickListener {
            browserBox.visibility = View.GONE
            libraryScroll.visibility = View.VISIBLE
        }

        browserBtn.setOnClickListener {
            browserBox.visibility = View.VISIBLE
            libraryScroll.visibility = View.GONE
        }

        return root
    }

    private fun setupBrowser() {
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.settings.allowFileAccess = false

        web.webViewClient = WebViewClient()

        web.setDownloadListener { url, _, contentDisposition, mime, _ ->
            val request = DownloadManager.Request(Uri.parse(url))
                .setTitle(
                    URLUtil.guessFileName(
                        url,
                        contentDisposition,
                        mime
                    )
                )
                .setDescription("Downloading music to WaveMusic")
                .setMimeType(mime)
                .setNotificationVisibility(
                    DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED
                )
                .setDestinationInExternalFilesDir(
                    this,
                    Environment.DIRECTORY_MUSIC,
                    URLUtil.guessFileName(url, contentDisposition, mime)
                )

            val manager =
                getSystemService(DOWNLOAD_SERVICE) as DownloadManager

            manager.enqueue(request)

            Toast.makeText(
                this,
                "Download started. Open Library after it finishes.",
                Toast.LENGTH_LONG
            ).show()
        }

        web.loadUrl("https://www.google.com/")
    }

    private fun refreshLibrary() {
        val dir = getExternalFilesDir(Environment.DIRECTORY_MUSIC)
        dir?.listFiles()?.filter { isAudio(it) }?.forEach { file ->
            if (tracks.none { it.uri.toString() == Uri.fromFile(file).toString() }) {
                tracks.add(
                    Track(
                        file.nameWithoutExtension,
                        Uri.fromFile(file),
                        true
                    )
                )
            }
        }

        if (::libraryBox.isInitialized) {
            libraryBox.removeAllViews()

            if (tracks.isEmpty()) {
                libraryBox.addView(TextView(this).apply {
                    text = "No music yet.\nAdd files or browse the internet."
                    textSize = 17f
                    setTextColor(0xFF999999.toInt())
                    setPadding(12, 30, 12, 30)
                })
            }

            tracks.forEachIndexed { index, track ->
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    setPadding(10, 14, 10, 14)
                }

                val info = TextView(this).apply {
                    text = "♫  ${track.title}"
                    textSize = 17f
                    setTextColor(0xFFFFFFFF.toInt())
                    setOnClickListener { load(index) }
                }

                row.addView(info, LinearLayout.LayoutParams(0, -2, 1f))

                val delete = Button(this).apply {
                    text = "✕"
                    setOnClickListener {
                        if (index == current) {
                            player.stop()
                            current = -1
                            titleText.text = "No song selected"
                            artistText.text = "Add music to begin"
                        }
                        tracks.removeAt(index)
                        refreshLibrary()
                    }
                }

                row.addView(delete)
                libraryBox.addView(row)
            }
        }
    }

    private fun load(index: Int) {
        if (index !in tracks.indices) return

        current = index
        val track = tracks[index]

        player.setMediaItem(MediaItem.fromUri(track.uri))
        player.prepare()

        titleText.text = track.title
        artistText.text = if (track.local) "Local / Downloaded" else "Internet"
        playButton.text = "▶"
    }

    private fun togglePlay() {
        if (current == -1) {
            if (tracks.isNotEmpty()) load(0) else return
        }

        if (player.isPlaying) {
            player.pause()
            playButton.text = "▶"
        } else {
            player.play()
            playButton.text = "⏸"
        }
    }

    private fun next() {
        if (tracks.isEmpty()) return
        val next = if (current + 1 >= tracks.size) 0 else current + 1
        load(next)
        player.play()
        playButton.text = "⏸"
    }

    private fun previous() {
        if (tracks.isEmpty()) return
        val prev = if (current - 1 < 0) tracks.size - 1 else current - 1
        load(prev)
        player.play()
        playButton.text = "⏸"
    }

    private fun getDisplayName(uri: Uri): String {
        var name = "Local Music"
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            val index = c.getColumnIndex(
                android.provider.OpenableColumns.DISPLAY_NAME
            )
            if (c.moveToFirst() && index >= 0) {
                name = c.getString(index)
            }
        }
        return name.substringBeforeLast(".")
    }

    private fun isAudio(file: File): Boolean {
        val n = file.name.lowercase()
        return n.endsWith(".mp3") ||
                n.endsWith(".m4a") ||
                n.endsWith(".wav") ||
                n.endsWith(".ogg") ||
                n.endsWith(".flac") ||
                n.endsWith(".aac")
    }

    override fun onDestroy() {
        player.release()
        web.destroy()
        super.onDestroy()
    }
}
